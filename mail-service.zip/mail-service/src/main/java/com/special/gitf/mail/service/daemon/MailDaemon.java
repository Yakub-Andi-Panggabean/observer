package com.special.gitf.mail.service.daemon;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.UUID;
import java.util.concurrent.TimeUnit;

import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import com.special.gitf.mail.service.MailService;

@Service
public class MailDaemon implements MailService {

	@Autowired
	private JavaMailSenderImpl sender;

	@Value("${mail.user}")
	private String mailSender;

	@Override
	public void sendMail(Connection connection) throws Exception {

		PreparedStatement statement = connection
				.prepareStatement("select user_email as email from user_web where user_status = ?");
		statement.setInt(1, 0);
		ResultSet result = statement.executeQuery();
		while (result.next()) {
			// send email
			UUID token = UUID.randomUUID();

			processMessage(connection, token.toString().replace("-", "")
					.toUpperCase(), result.getString("email"));

			TimeUnit.SECONDS.sleep(1);

		}

	}

	private void processMessage(Connection connection, String token,
			String destination) throws Exception {

		MimeMessage message = sender.createMimeMessage();
		MimeMessageHelper helper = new MimeMessageHelper(message);
		helper.setFrom(mailSender);
		helper.setTo(destination);
		helper.setText(token);
		sender.send(message);
		insertToken(connection, destination, token);

	}

	private void insertToken(Connection connection, String email, String token)
			throws Exception {
		PreparedStatement statement = connection
				.prepareStatement("insert into mail_token(mail,token,current_date) values (?,?,?)");
		statement.setString(1, email);
		statement.setString(2, token);
		statement.setDate(3, new Date(new java.util.Date().getTime()));
		statement.execute();
	}

}
