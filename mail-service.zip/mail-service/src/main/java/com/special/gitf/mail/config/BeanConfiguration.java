package com.special.gitf.mail.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.stereotype.Component;

@Component
public class BeanConfiguration {

	@Value("${mail.server}")
	private String mailServer;

	@Value("${mail.server.port}")
	private int mailPort;

	@Value("${mail.user}")
	private String mailUser;

	@Value("${mail.password}")
	private String mailPassword;

	@Value("${db.url}")
	private String url;

	@Value("${db.driver}")
	private String driver;

	@Value("${db.user}")
	private String user;

	@Value("${db.password}")
	private String password;

	@Bean
	Connection initConnection() {
		Connection connection = null;
		try {
			Class.forName(driver);
			connection = DriverManager.getConnection(url, user, password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}

	@Bean
	JavaMailSenderImpl initMailSender() {
		JavaMailSenderImpl sender = new JavaMailSenderImpl();
		sender.setHost(mailServer);
		sender.setPort(mailPort);

		sender.setUsername(mailUser);
		sender.setPassword(mailPassword);

		Properties props = new Properties();

		props.put("mail.transport.protocol", "smtp");
		props.put("mail.smtp.auth", "true");
		props.put("mail.smtp.starttls.enable", "true");
		// props.put("mail.smtp.ssl.enable", "true");

		sender.setJavaMailProperties(props);

		return sender;
	}
}
