/**
 * 
 */
$(document).ready(function() {

	$(".dropdown-button").dropdown();
	$('.slider').slider({
		height : 250,
		indicators : false,
		full_width : true
	});

});