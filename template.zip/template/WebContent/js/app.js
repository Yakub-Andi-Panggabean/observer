/**
 * 
 */
$(document).ready(function() {
	
	$("#button-booking").click(function() {
		$("#book_modal").modal();
	});

});
